<?php $__env->startSection('title', 'Create new product'); ?>
<?php $__env->startSection('content'); ?>


    <section class="banner-section">
        <div class="container">
            <div class="banner-main">


                <?php $__currentLoopData = $categoriesMain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="banner-item">
                        <div class="banner-image"></div>
                        <div class="banner-text font-second"> <?php echo e($category->title); ?></div>
                        
                        <a href="/<?php echo e($category->belongs_to); ?>/<?php echo e($category->url); ?>" class="banner-link">
                            <span class="arrow banner-arrow-icon"></span>
                            <?php echo e($category->title); ?>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="banner-item">
                    <div class="banner-image"></div>
                    <div class="banner-text font-second"> Gallery</div>
                    
                    <a href="/gallery" class="banner-link">
                        <span class="arrow banner-arrow-icon"></span>
                        Gallery
                    </a>
                </div>

            </div>
        </div>
    </section>









    
    <section class="product-section">
        <div class="container">
            <div class="product-section-wrapper">
                <div class="product-section-heading">
                    <h4 class="title-heading font-second">Trending Products</h4>
                    <a href="/" class="explore-link">
                        <span>Explore products</span>
                        <span class="arrow"></span>
                    </a>
                </div>
                <div class="product-section-list-wrapper row">
                    <?php if(count($products) > 0): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-section-list-item col-6 col-sm-4 col-md-3 col-lg-2">
                                <div class="product-wrapper">
                                    <a href="/products/<?php echo e(Str::slug(explode(',', $product->category_id)[1])); ?>/<?php echo e(Str::slug(explode(',', $product->sub_category_id)[1])); ?>/<?php echo e($product->url); ?>"
                                        class="product-links-wrapper">
                                        <div class="product-image-wrapper">


                                            <img src="<?php echo e(Storage::url(explode(', ', $product->images)[0])); ?>"
                                                alt="">
                                        </div>
                                        <div class="product-text-wrapper">
                                            <span class="item-left">3 Left</span>
                                            <p><?php echo e($product->name); ?></p>
                                        </div>
                                    </a>

                                    <div class="product-link-wrapper">
                                        <button class="product-add-cart-btn"
                                            onclick="addToCart('<?php echo e($product->product_code); ?>')">
                                            <span> <img src="<?php echo e(asset('/assets/front-end/images/header/cart.svg')); ?>"
                                                    alt=""></span>
                                            <span>Add to cart</span>
                                        </button>
                                        <a href="" class="whatsap-message">
                                            <img src="<?php echo e(asset('/assets/front-end/images/products/whatsapp.svg')); ?>"
                                                alt="">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="no-data-found">
                            <span class="no-found-error-icon"></span>
                            <h3 class="font-second"> Sorry!</h3>
                            <p>No data found</p>
                        </div>


                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    




    

    <section class="service-section">
        <div class="container">
            <div class="service-section-wrapper">
                <div class="product-section-heading">
                    <h4 class="title-heading font-second">Our Best Services</h4>
                    <a href="/" class="explore-link">
                        <span>Explore Services</span>
                        <span class="arrow"></span>
                    </a>
                </div>
            </div>
            <div class="service-section-list-wrapper row">
                <?php if(count($services) > 0): ?>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="service-section-list-item col-12 col-sm-6 col-lg-3">

                            <a href="/services/<?php echo e(Str::slug(explode(',', $service->category_id)[1])); ?>/<?php echo e($service->url); ?>"
                                class="service-main-wrapper">
                                <div class="service-image-wrapper">
                                    <div class="service-image-inner">
                                        <img src="<?php echo e(Storage::url($service->image)); ?>" alt="">
                                    </div>
                                </div>
                                <div class="service-content">
                                    <h4><?php echo e($service->name); ?></h4>
                                    <p><?php echo e($service->thumb_description); ?></p>
                                    <a href="/" class="explore-link">
                                        <span>Learn more</span>
                                        <span class="arrow-blue"></span>
                                    </a>
                                </div>
                            </a>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="no-data-found">
                        <span class="no-found-error-icon"></span>
                        <h3 class="font-second"> Sorry!</h3>
                        <p>No data found</p>
                    </div>


                <?php endif; ?>
            </div>
        </div>
    </section>
    




    
    <section class="happy-customers">
        <div class="container">
            <div class="happy-customers-main">

                <div class="product-section-heading">
                    <h4 class="title-heading font-second center">Happy customers</h4>

                </div>

                <div class="happy-customers-slider-inner">
                    <div class="happy-customers-slider-items">


                        <div class="happy-customers-item">
                            <div class="happy-customers-star">
                                <div class="happy-customers-star-wrapper">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                </div>
                            </div>
                            <div class="happy-customers-content">
                                <p class="happy-customers-description">Incorporating yoga into your routine contributes to
                                    both physical and mental health, promoting a balanced and healthier.</p>
                                <h5 class="happy-customers-name font-second">Lora Minsa</h5>
                                <span class="happy-customers-position">Teacher</span>
                            </div>
                        </div>


                        <div class="happy-customers-item">
                            <div class="happy-customers-star">
                                <div class="happy-customers-star-wrapper">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                </div>
                            </div>
                            <div class="happy-customers-content">
                                <p class="happy-customers-description">Incorporating yoga into your routine contributes to
                                    both physical and mental health, promoting a balanced and healthier.</p>
                                <h5 class="happy-customers-name font-second">Lora Minsa</h5>
                                <span class="happy-customers-position">Teacher</span>
                            </div>
                        </div>


                        <div class="happy-customers-item">
                            <div class="happy-customers-star">
                                <div class="happy-customers-star-wrapper">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                </div>
                            </div>
                            <div class="happy-customers-content">
                                <p class="happy-customers-description">Incorporating yoga into your routine contributes to
                                    both physical and mental health, promoting a balanced and healthier.</p>
                                <h5 class="happy-customers-name font-second">Lora Minsa</h5>
                                <span class="happy-customers-position">Teacher</span>
                            </div>
                        </div>


                        <div class="happy-customers-item">
                            <div class="happy-customers-star">
                                <div class="happy-customers-star-wrapper">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                </div>
                            </div>
                            <div class="happy-customers-content">
                                <p class="happy-customers-description">Incorporating yoga into your routine contributes to
                                    both physical and mental health, promoting a balanced and healthier.</p>
                                <h5 class="happy-customers-name font-second">Lora Minsa</h5>
                                <span class="happy-customers-position">Teacher</span>
                            </div>
                        </div>

                        <div class="happy-customers-item">
                            <div class="happy-customers-star">
                                <div class="happy-customers-star-wrapper">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                    <img src="<?php echo e(asset('/assets/front-end/images/customers/01-star.svg')); ?>"
                                        alt="">
                                </div>
                            </div>
                            <div class="happy-customers-content">
                                <p class="happy-customers-description">Incorporating yoga into your routine contributes to
                                    both physical and mental health, promoting a balanced and healthier.</p>
                                <h5 class="happy-customers-name font-second">Lora Minsa</h5>
                                <span class="happy-customers-position">Teacher</span>
                            </div>
                        </div>



                    </div>
                </div>


            </div>
        </div>
    </section>
    




    
    <section class="product-section">
        <div class="container">
            <div class="product-section-wrapper">
                <div class="product-section-heading">
                    <h4 class="title-heading font-second">Best Value</h4>
                    <a href="/" class="explore-link">
                        <span>Explore products</span>
                        <span class="arrow"></span>
                    </a>
                </div>
                <div class="product-section-list-wrapper row">
                    <?php if(count($products) > 0): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-section-list-item col-6 col-sm-4 col-md-3 col-lg-2">
                                <div class="product-wrapper">
                                    <a href="/products/<?php echo e(Str::slug(explode(',', $product->category_id)[1])); ?>/<?php echo e(Str::slug(explode(',', $product->sub_category_id)[1])); ?>/<?php echo e($product->url); ?>"
                                        class="product-links-wrapper">
                                        <div class="product-image-wrapper">


                                            <img src="<?php echo e(Storage::url(explode(', ', $product->images)[0])); ?>"
                                                alt="">
                                        </div>
                                        <div class="product-text-wrapper">
                                            <span class="item-left">3 Left</span>
                                            <p><?php echo e($product->name); ?></p>
                                        </div>
                                    </a>

                                    <div class="product-link-wrapper">
                                        <button class="product-add-cart-btn"
                                            onclick="addToCart('<?php echo e($product->product_code); ?>')">
                                            <span> <img src="<?php echo e(asset('/assets/front-end/images/header/cart.svg')); ?>"
                                                    alt=""></span>
                                            <span>Add to cart</span>
                                        </button>
                                        <a href="" class="whatsap-message">
                                            <img src="<?php echo e(asset('/assets/front-end/images/products/whatsapp.svg')); ?>"
                                                alt="">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="no-data-found">
                            <span class="no-found-error-icon"></span>
                            <h3 class="font-second"> Sorry!</h3>
                            <p>No data found</p>
                        </div>


                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/front-end/home/view.blade.php ENDPATH**/ ?>