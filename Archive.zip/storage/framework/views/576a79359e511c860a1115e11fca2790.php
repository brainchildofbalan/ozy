<?php $__env->startSection('title', 'Create new product'); ?>
<?php $__env->startSection('content'); ?>



    <div class="bread-crumbs">
        <div class="container">
            <ul>
                <li>
                    <a href="/">Home</a>
                </li>
                <li>
                    <a href="/services">Services</a>
                </li>
                <li>
                    <a
                        href="/services/<?php echo e(Str::slug(explode(',', $services->category_id)[1])); ?>"><?php echo e(explode(',', $services->category_id)[1]); ?></a>
                </li>



                <li>
                    <span><?php echo e($services->name); ?></span>
                </li>
            </ul>
        </div>
    </div>

    <section class="service-details-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-details-inner">
                        <div class="services-main-heading">

                            <h3 class="service-content-title font-second">
                                <?php echo e($services->name); ?>

                            </h3>


                            <a href="/enqyiry" class="enq-button">
                                Enquire now</a>
                        </div>


                        <div class="service-image-wrapper-detail">
                            <img src="<?php echo e(Storage::url($services->image)); ?>" alt="">
                        </div>

                        <div class="service-content-wrapper">

                            <div class="service-description">
                                <?php echo $services->description; ?>

                            </div>
                        </div>


                        <div class="service-action-wrappoer"></div>



                    </div>
                </div>
                <div class="col-lg-4"></div>
            </div>

        </div>
    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/front-end/service-details/view.blade.php ENDPATH**/ ?>