<?php $__env->startSection('title', 'Category'); ?>
<?php $__env->startSection('content'); ?>
    <div class="flex-grow-1 container-p-x container-p-y">
        

        <div class="card border-0">
            <ul class="list-group" id="sortable">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-id="<?php echo e($category->id); ?>" class="list-group-item"><?php echo e($category->title); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>









    </div>
    <script>
        var main_token = '<?php echo e(csrf_token()); ?>';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/admin/menus/order.blade.php ENDPATH**/ ?>