@extends('front-end.layout')
@section('title', 'Create new product')
@section('content')

    <section class="cart-wrapper">
        <div class="container">
            <div class="cart-main">




            </div>
        </div>
    </section>



@endsection
