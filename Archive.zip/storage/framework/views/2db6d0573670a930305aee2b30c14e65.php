<?php $__env->startSection('title', 'Category'); ?>
<?php $__env->startSection('content'); ?>
    <div class="flex-grow-1 container-p-x container-p-y">
        <div class="card mb-3 flex-row justify-content-between align-items-center p-3">
            <h5 class="card-header p-0">Uploaded Category</h5>
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Create new product</a>
        </div>
        <div class="card border-0">
            <div class="table-responsive text-nowrap card-body">
                <table class="table table-bordered ">
                    <thead>
                        <tr>
                            <th class="fw-bold">Name</th>
                            <th class="fw-bold">Created at</th>
                            <th class="fw-bold">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-bold text-black"><?php echo e($category->name); ?></td>
                                <td class="fw-medium text-black"><?php echo e($category->created_at); ?></td>
                                <td class="fw-medium">
                                    <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                            data-bs-toggle="dropdown"><i
                                                class="bx bx-dots-vertical-rounded"></i>More</button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="<?php echo e(route('categories.edit', $category->id)); ?>"">

                                                <span class="btn btn-danger">Edit</span></a>




                                            <form class="dropdown-item" method="post"
                                                action="<?php echo e(route('categories.destroy', $category->id)); ?>"
                                                onsubmit="return confirm('Are you sure you want to delete this category?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>









    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/admin/category/view.blade.php ENDPATH**/ ?>