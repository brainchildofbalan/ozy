<?php $__env->startSection('title', 'Create new product'); ?>
<?php $__env->startSection('content'); ?>

    <section class="cart-wrapper">
        <div class="container">
            <div class="cart-main">




            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/front-end/cart/view.blade.php ENDPATH**/ ?>