<?php $__env->startSection('title', 'Create new product'); ?>
<?php $__env->startSection('content'); ?>

    <section class="banner-section">
        <div class="container">
            <div class="banner-main">


                <?php $__currentLoopData = $categoriesMain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="banner-item">
                        <div class="banner-image"></div>
                        <div class="banner-text font-second"> <?php echo e($category->title); ?></div>
                        
                        <a href="/<?php echo e($category->belongs_to); ?>/<?php echo e($category->url); ?>" class="banner-link">
                            <span class="arrow banner-arrow-icon"></span>
                            <?php echo e($category->title); ?>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="banner-item">
                    <div class="banner-image"></div>
                    <div class="banner-text font-second"> Gallery</div>
                    
                    <a href="/gallery" class="banner-link">
                        <span class="arrow banner-arrow-icon"></span>
                        Gallery
                    </a>
                </div>

            </div>
        </div>
    </section>




    
    
    








    
    <section class="service-section">
        <div class="container">
            <div class="product-section-wrapper">
                <div class="product-section-heading">
                    <h4 class="title-heading font-second">All products</h4>
                    
                </div>
                <div class="product-section-list-wrapper row">
                    <?php if(count($services) > 0): ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="service-section-list-item col-12 col-sm-6 col-lg-3">

                                <a href="/services/<?php echo e(Str::slug(explode(',', $service->category_id)[1])); ?>/<?php echo e($service->url); ?>"
                                    class="service-main-wrapper">
                                    <div class="service-image-wrapper">
                                        <div class="service-image-inner">
                                            <img src="<?php echo e(Storage::url($service->image)); ?>" alt="">
                                        </div>
                                    </div>
                                    <div class="service-content">
                                        <h4><?php echo e($service->name); ?></h4>
                                        <p><?php echo e($service->thumb_description); ?></p>
                                        <a href="/" class="explore-link">
                                            <span>Learn more</span>
                                            <span class="arrow-blue"></span>
                                        </a>
                                    </div>
                                </a>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="no-data-found">
                            <span class="no-found-error-icon"></span>
                            <h3 class="font-second"> Sorry!</h3>
                            <p>No data found</p>
                        </div>


                    <?php endif; ?>


                </div>
            </div>

        </div>
    </section>
    





<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/front-end/services/view.blade.php ENDPATH**/ ?>