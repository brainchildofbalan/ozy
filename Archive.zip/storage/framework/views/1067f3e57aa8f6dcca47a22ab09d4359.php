<?php $__env->startSection('title', 'Category'); ?>
<?php $__env->startSection('content'); ?>
    <div class="flex-grow-1 container-p-x container-p-y">
        <div class="card p-3">
            <h4 class="card-header  p-0 mb-3">Sub category details</h4>

            <p class="mb-1"><strong>Category ID:</strong> <?php echo e($category->category_id); ?></p>
            <p class="mb-1"><strong>Name:</strong> <?php echo e($category->name); ?></p>
            <p class="mb-1"><strong>Order:</strong> <?php echo e($category->order); ?></p>

            <?php if($category->image): ?>
                <img src="<?php echo e(Storage::url($category->image)); ?>" alt="<?php echo e($category->name); ?> Image" style="max-width: 300px;">
            <?php else: ?>
                <p>No image available</p>
            <?php endif; ?>

            <div class="mt-3">
                <a href="<?php echo e(route('sub-categories.index')); ?>" class="btn btn-secondary">Back to Categories</a>
                <a href="<?php echo e(route('sub-categories.edit', $category->id)); ?>" class="btn btn-primary">Edit</a>

                <form method="post" action="<?php echo e(route('sub-categories.destroy', $category->id)); ?>" class="d-inline"
                    onsubmit="return confirm('Are you sure you want to delete this category?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/admin/sub-category/show.blade.php ENDPATH**/ ?>