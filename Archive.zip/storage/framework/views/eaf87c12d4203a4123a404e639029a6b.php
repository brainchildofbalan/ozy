<?php $__env->startSection('title', 'Category'); ?>
<?php $__env->startSection('content'); ?>
    <div class="flex-grow-1 container-p-x container-p-y">
        <div class="card mb-3 flex-row justify-content-between align-items-center p-3">
            <h5 class="card-header p-0">Uploaded Order</h5>
            <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">Create new product</a>
        </div>
        <div class="card border-0">
            <div class="table-responsive text-nowrap card-body">
                <table class="table table-bordered ">
                    <thead>
                        <tr>
                            <th class="fw-bold">Name</th>
                            <th class="fw-bold">products</th>
                            <th class="fw-bold">Created at</th>
                            <th class="fw-bold">Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-bold text-black"><?php echo e($order->firstName); ?></td>
                                <td>

                                    <?php
                                        $arrayOfObjects = json_decode($order->products);
                                    ?>
                                    <div style="display: flex; flex-wrap: wrap; position: relative;">
                                        <?php if($arrayOfObjects !== null): ?>
                                            <?php $__currentLoopData = $arrayOfObjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span style="position: relative;">
                                                    <img src="<?php echo e(Storage::url($object->images)); ?>"
                                                        style="width: 50px; height: 50px; object-fit: cover; margin: 5px; border: 1px solid #dedede; padding: 10px;">
                                                    <span
                                                        style="position: absolute; left: 8px; top: 8px; background-color: #fff; width: 10px; height: 10px; font-size: 10px; display: flex; justify-content: center; align-items: center; color: #000"><?php echo e($object->qty); ?></span>
                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                        <?php endif; ?>
                        </td>
                        <td class="fw-medium text-black"><?php echo e($order->created_at); ?></td>
                        <td class="fw-medium">
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i>More</button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('orders.edit', $order->id)); ?>"">

                                        <span class="btn btn-danger">Edit</span></a>




                                    <form class="dropdown-item" method="post"
                                        action="<?php echo e(route('orders.destroy', $order->id)); ?>"
                                        onsubmit="return confirm('Are you sure you want to delete this category?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>









    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/admin/orders/view.blade.php ENDPATH**/ ?>