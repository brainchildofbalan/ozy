@extends('front-end.layout')
@section('title', 'Create new product')
@section('content')



    <div class="bread-crumbs">
        <div class="container">
            <ul>
                <li>
                    <a href="/">Home</a>
                </li>
                <li>
                    <a href="/services">Services</a>
                </li>
                <li>
                    <a
                        href="/services/{{ Str::slug(explode(',', $services->category_id)[1]) }}">{{ explode(',', $services->category_id)[1] }}</a>
                </li>



                <li>
                    <span>{{ $services->name }}</span>
                </li>
            </ul>
        </div>
    </div>

    <section class="service-details-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-details-inner">
                        <div class="services-main-heading">

                            <h3 class="service-content-title font-second">
                                {{ $services->name }}
                            </h3>


                            <a href="/enqyiry" class="enq-button">
                                Enquire now</a>
                        </div>


                        <div class="service-image-wrapper-detail">
                            <img src="{{ Storage::url($services->image) }}" alt="">
                        </div>

                        <div class="service-content-wrapper">

                            <div class="service-description">
                                {!! $services->description !!}
                            </div>
                        </div>


                        <div class="service-action-wrappoer"></div>



                    </div>
                </div>
                <div class="col-lg-4"></div>
            </div>

        </div>
    </section>




@endsection
