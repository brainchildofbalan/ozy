<?php $__env->startSection('title', 'Create new product'); ?>
<?php $__env->startSection('content'); ?>



    <div class="bread-crumbs">
        <div class="container">
            <ul>
                <li>
                    <a href="/">Home</a>
                </li>
                <li>
                    <a href="/products">Products</a>
                </li>
                <li>
                    <a
                        href="/products/<?php echo e(Str::slug(explode(',', $products->category_id)[1])); ?>"><?php echo e(explode(',', $products->category_id)[1]); ?></a>
                </li>


                <li>
                    <a
                        href="/products/<?php echo e(Str::slug(explode(',', $products->category_id)[1])); ?>/<?php echo e(Str::slug(explode(',', $products->sub_category_id)[1])); ?>"><?php echo e(explode(',', $products->sub_category_id)[1]); ?></a>
                </li>

                <li>
                    <span><?php echo e($products->name); ?></span>
                </li>
            </ul>
        </div>
    </div>

    

    <section class="product-details-wrapper">
        <div class="container">
            <div class="product-details-inner row">
                <div class="product-image-slider col-12 col-lg-5">

                    <div class="slider-inner">


                        <!-- Slider main container -->
                        <div class="swiper">
                            <!-- Additional required wrapper -->
                            <div class="swiper-wrapper">
                                <!-- Slides -->
                                <?php $__currentLoopData = explode(', ', $products->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="image-wrapper-slider">
                                            <img src="<?php echo e(Storage::url($image)); ?>" alt="">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <!-- If we need pagination -->
                            <div class="swiper-pagination"></div>

                            <!-- If we need navigation buttons -->
                            <div class="swiper-button-prev"></div>
                            <div class="swiper-button-next"></div>

                            <!-- If we need scrollbar -->
                            
                        </div>

                    </div>

                </div>
                <div class="product-content-and-action-wrapper col-12 col-lg-7">

                    <h3 class="title-wrapper">
                        <?php echo e($products->name); ?>

                    </h3>
                    <div class="button-wrapper">
                        <button class="product-add-cart-btn" onclick="addToCart('<?php echo e($products->product_code); ?>')">
                            <span> <img src="<?php echo e(asset('/assets/front-end/images/header/cart.svg')); ?>" alt=""></span>
                            <span>Add to cart</span>
                        </button>
                        <a href="" class="whatsap-message">
                            <img src="<?php echo e(asset('/assets/front-end/images/products/whatsapp.svg')); ?>" alt="">
                        </a>
                    </div>

                    <div class="info-main">
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo maxime odio quis eos optio
                            exercitationem
                        </p>
                    </div>
                    <div class="content-wrapper">
                        <?php echo $products->description; ?>


                    </div>
                </div>
            </div>
        </div>
    </section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/front-end/products-details/view.blade.php ENDPATH**/ ?>