<!DOCTYPE html>
<html class="light-style layout-menu-fixed" data-theme="theme-default" data-assets-path="http://localhost:8001/assets/"
    data-base-url="http://localhost:8001" data-framework="laravel" data-template="vertical-menu-laravel-template-free">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'Your Default Title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('/assets/admin/css/main-style.css')); ?>">
    <script src="<?php echo e(asset('/assets/admin/js/helpers.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/admin/js/config.js')); ?>"></script>

</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>

</body>


<script src="<?php echo e(asset('/assets/admin/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/admin/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/admin/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/admin/js/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/admin/js/menu.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/admin/js/main.js')); ?>"></script>


</html>
<?php /**PATH /Users/aneesh/Documents/jeevan/ozy/resources/views/auth/layouts.blade.php ENDPATH**/ ?>